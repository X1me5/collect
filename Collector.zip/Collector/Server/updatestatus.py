# -*- coding: utf-8 -*-
# @Time    : 2020/12/21 5:41 下午
# @Author  : Ximes
# @FileName: updatestatus.py
from watchdog.observers import Observer
from watchdog.events import *
import time
import smtplib
from email.mime.text import MIMEText
from email.header import Header
import requests
import configparser
class FileEventHandler(FileSystemEventHandler):
    def __init__(self):
        FileSystemEventHandler.__init__(self)
    def on_created(self, event):
        if event.src_path[-25] not in goodlist:
            goodlist.append(event.src_path[-25])
        #lineid（1)-cameraid(0)-year(xxxx)-month(xx)-day(xx)-hour(xx)-minute(xx)-second(xx).jpg
        #src_path[-25] means cameraid
def updatesql(goodlist,cf):
    goodstr = '-1'#-1 will never be added to goodlist,so it could prevent from the empty str make the sql error
    goodstr += ','.join(goodlist).replace(',','')
    headers = {
        "Content-Type": 'application/json',
        "token": cf.get("updatesql parameter", "token")}#'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MDkxMjQxNjgsInVzZXJuYW1lIjoiWGltZXMifQ.hBeelosXaCsEOI5Roj9DlaU0u9q1rgB19WokXDT9Qx0'}
    msg = {'ids':goodstr}#send it to the interface
    url1 = cf.get("updatesql parameter","url1")#set working status
    url2 = cf.get("updatesql parameter","url2")#set not working status
    try:
        r = requests.post(url1, params=msg, headers=headers)
        r = requests.post(url2, params=msg, headers=headers)
        print('finish update the sql')
        logging.info('finish update the sql')
    except:
        logging.error("There is a error in this file", exc_info=1)
def warning(goodlist,constantsendtime,skiptime,cf):
    if len(goodlist)==0 and constantsendtime <3:#if there is no pic added and have not sent 3 times constantly
        constantsendtime+=1
        mail_host = cf.get("e-mail parameter","host")  # 设置服务器
        mail_user = cf.get("e-mail parameter","user")  # 用户名
        mail_pass = cf.get("e-mail parameter","password")  # 口令
        sender = cf.get("e-mail parameter","sender")
        receivers = [cf.get("e-mail parameter","receivers")]  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
        message = MIMEText(cf.get("e-mail parameter","message"), 'plain', 'utf-8')
        message['From'] = Header(cf.get("e-mail parameter","messagefrom"), 'utf-8')
        message['To'] = Header(cf.get("e-mail parameter","messageto"), 'utf-8')
        subject = cf.get("e-mail parameter","subject")
        message['Subject'] = Header(subject, 'utf-8')
        try:
            smtpObj = smtplib.SMTP()
            try:
                smtpObj.connect(mail_host, int(cf.get("e-mail parameter","port")))  # 连接
            except:
                print('Error')
                logging.error("There is a error in this file", exc_info=1)
            smtpObj.login(mail_user, mail_pass)
            smtpObj.sendmail(sender, receivers, message.as_string())
            print("检测到未有图片生成，邮件发送成功")
            logging.info('检测到未有图片生成，邮件发送成功')
        except smtplib.SMTPException:
            print("Error: 无法发送邮件")
            logging.error("There is a error in this file", exc_info=1)
        return constantsendtime,skiptime
    elif len(goodlist)==0 and constantsendtime >=3:#if there is no pic added and have sent 3 times constantly
        if skiptime <10:#5*10+1*5+1*5 = 60 min
            skiptime+=1
            logging.info('因连续发送三次，故邮件发送程序正在休眠，已休眠'+str(int(skiptime)*5+10)+'分钟')
        else:
            logging.info('休眠已满一小时，邮件发送程序重新开始启动')
            skiptime =0 #one hour has passed,reset the skiptime
            constantsendtime=0
        return constantsendtime,skiptime
    else:#if there is pic added
        constantsendtime = 0 #no need to send e-mail,so the constantsendtime and skiptime could be reset.
        skiptime = 0
        logging.info('检测到有图片生成，无需发送邮件')
        return constantsendtime,skiptime
if __name__ == '__main__':
    cf = configparser.ConfigParser()
    cf.read('conf/updatestatus.ini')
    #token = cf.get("Ali-cloud database", "host")  # 获取[Mysql-Database]中host对应的值
    constantsendtime = 0 #inistialize the time of sending e-mail constantly
    skiptime = 0 #initialize the skiptime of e-mail sleeping.if send 3 times constantly,we will sleep for 12 turns.
    #logging
    goodlist = []
    logging.basicConfig(level=logging.INFO,
                        format='levelname:%(levelname)s filename: %(filename)s '
                               'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
                               ' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
                        filename='./updatestatus.log', filemode="a")
    #watchdog
    observer = Observer()
    event_handler = FileEventHandler()
    observer.schedule(event_handler,"/data/fileserver/backup",True)
    observer.start()
    print('begin to check')
    logging.info('begin to check')
    try:
        while True:
            print('sleeping')
            logging.info('sleeping')
            time.sleep(5)
            print('finish sleeping,start checking')
            logging.info('finish sleeping,start checking')
            updatesql(goodlist,cf) #update the data table
            constantsendtime,skiptime=warning(goodlist,constantsendtime,skiptime,cf)   #send e-mail to warn
            goodlist.clear()
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
