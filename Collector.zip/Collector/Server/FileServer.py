#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time    : 2020/12/21 5:41 下午
# @Author  : Ximes
# @FileName: FileServer.py
import socket
import os
import sys
import struct
import logging
import threading
import configparser
class BadlinkException(Exception):       #自定义异常，用于判断连接是否中断
    pass
def socket_service_image(host,port,extractcode,cf):
    logging.basicConfig(level=logging.DEBUG,
                            format='levelname:%(levelname)s filename: %(filename)s '
                                   'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
                                   ' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
                            filename='./FileServer.log', filemode="a")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host,port))
        s.listen(int(cf.get("Server Parameter", "maxconnect")))
    except socket.error as msg:
        print(msg)
        sys.exit(1)

    print("Wait for Connection.....................")

    while True:
        sock, addr = s.accept()  #addr是一个元组(ip,port)
        #t1 = threading.Thread(target=deal_image,args=(sock,addr))
        #t1.start()
        deal_image(sock,addr,extractcode)
def deal_image(sock, addr, extractcode):
    print("Accept connection from {0}".format(addr))  #查看发送端的ip和端口
    logging.info("Accept connection from {0}".format(addr))
    sock.settimeout(int(cf.get("Server Parameter", "timeout")))
    while True:
      try:
        fileinfo_size = struct.calcsize(extractcode)
        buf = sock.recv(fileinfo_size)   #接收图片名
        if buf:
            filename, filesize = struct.unpack(extractcode, buf)#extractcode是和客户端保持一致的码，可用于过滤非客户端的信息
            if filesize != 0:
                fn = filename.decode().strip('\x00')
                fn = fn + ".tmp"
                new_filename = os.path.join(cf.get("Server Parameter", "savepath"), fn)  #在服务器端新建图片名（可以不用新建的，直接用原来的也行，只要客户端和服务器不是同一个系统或接收到的图片和原图片不在一个文件夹下）
                recvd_size = 0
                fp = open(new_filename, 'wb')
                print('开始传输')
                logging.info("开始传输")
                while not recvd_size == filesize:
                    if filesize - recvd_size > int(cf.get("Server Parameter", "packagesize")):#一次接收1KB
                        data = sock.recv(int(cf.get("Server Parameter", "packagesize")))
                        if not data:    #如果客户端连接中断，无法再收到数据
                            fp.close()
                            os.remove(new_filename) #删除tmp
                            print('link has been closed from the client,close the link')
                            logging.info('link has been closed from the client,close the link')
                            raise Exception #关闭连接
                        recvd_size += len(data)
                    else:
                        data = sock.recv(int(cf.get("Server Parameter", "packagesize")))
                        if not data:
                            fp.close()
                            os.remove(new_filename)
                            print('link has been closed from the client,close the link')
                            logging.info('link has been closed from the client,close the link')
                            raise Exception
                        recvd_size = filesize
                    fp.write(data)  #写入图片数据
                logging.info('传输完毕')
                fp.close()
                old_filename = new_filename.replace(".tmp","")
                os.rename(new_filename,old_filename)
                sock.send('send over.'.encode("utf-8"))
                print(old_filename +' has been saved,waiting for connection...')
                logging.info(old_filename+"has been saved,waiting for connection...")
            else :
                print('there is an unkown client trying to connect,refuse it.')
                logging.info('there is an unkown client trying to connect,refuse it.')
      except Exception as e:
            logging.error("There is a error in this file", exc_info=1)
      finally:
          sock.close()
          break
if __name__ == '__main__':
    cf = configparser.ConfigParser()
    cf.read('conf/FileServer.ini')
    host = cf.get("Ali-cloud database", "host")
    port = int(cf.get("Ali-cloud database", "port"))
    extractcode = cf.get("Ali-cloud database", "extractcode")
    socket_service_image(host,port,extractcode,cf)
