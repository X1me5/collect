# -*- coding: utf-8 -*
import PIL.Image as Image
from PIL import ImageFile
def changesize(filename):
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    infile = filename
    outfile = filename
    im = Image.open(infile)
    (x, y) = im.size  # read image size
    x_s = 1664  # define standard width
    y_s = y * x_s // x  # calc height based on standard width
    out = im.resize((x_s, y_s), Image.ANTIALIAS)  # resize image with high-quality
    out.save(outfile)
if __name__ == '__main__':
    changesize('GrabImage/2020-11-18-15-28-45.jpg')
