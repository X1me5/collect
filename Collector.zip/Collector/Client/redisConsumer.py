#!/usr/bin/env python
# -*- coding=utf-8 -*-

import redis
import time
import requests
import socket
import sys
import struct
import os
import logging

def socket_client(filename,HOST,PORT):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((HOST,PORT))
    except socket.error as msg:
        print(msg)
        sys.exit(1)

    #print(s.recv(1024))

    while 1:
        #filepath = input("please input file path: ")
        filepath = filename
        if os.path.isfile(filepath):
            # 定义定义文件信息。128s表示文件名为128bytes长，l表示一个int或log文件类型，在此为文件大小
            fileinfo_size = struct.calcsize('128sl')
            # 定义文件头信息，包含文件名和文件大小
            print("filesize is: " + str(os.stat(filepath).st_size))
            fhead = struct.pack('128sl', bytes(os.path.basename(filepath).encode('utf-8')),os.stat(filepath).st_size)
            s.send(fhead)
            print ('client filepath: {0}'.format(filepath))
            fp = open(filepath, 'rb')
            print('filepath is :'+filepath)
            while 1:
                data = fp.read(1024)
                if not data:
                    print ('{0} file send over...'.format(filepath))
                    break
                s.send(data)
        s.close()
        break

def sock_client_image(filename,HOST,PORT):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST,PORT))  #服务器和客户端在不同的系统或不同的主机下时使用的ip和端口，首先要查看服务器所在的系统网卡的ip
            # s.connect(('127.0.0.1', 6666))  #服务器和客户端都在一个系统下时使用的ip和端口
        except socket.error as msg:
            print(msg)
            #print(sys.exit(1))
            logging.error("There is a error in connecting,trying to reconnect", exc_info=1)
            time.sleep(10)
        print("filesize is: " + str(os.stat(filename).st_size))
        fhead = struct.pack(b'128sq', bytes(os.path.basename(filename), encoding='utf-8'), os.stat(filename).st_size)  #将xxx.jpg以128sq的格式打包
        try:
            s.send(fhead)
        except:
            logging.error("There is a error in connecting,trying to reconnect", exc_info=1)
            s.close()
        try:
            fp = open(filename, 'rb')  #打开要传输的图片
        except:
            print("error is here lalala")
        #print('size is :'+str(os.getsize(filename)))
        while True:
            try:
                data = fp.read(1024) #读入图片数据
            except:
                logging.error("There is a error in connecting,trying to reconnect", exc_info=1)
                pass
            if not data:
                count = 0;
                break
            try:
                s.send(data)  #以二进制格式发送图片数据
            except:
                logging.error("There is a error in connecting,trying to reconnect", exc_info=1)
                s.close()
        while True:
            count+=1
            try:
                recv_data = s.recv(1024)
            except:
                logging.error("There is a error in connecting,trying to reconnect", exc_info=1)
                s.close()
            if recv_data:
                print('{0} send over...'.format(filename))
                logging.info('{0} send over...'.format(filename))
                print (recv_data.decode('utf-8'))
                break
            elif count >= 1000: #等候时间达到一秒，就不再等候了
                print("no detection return to client")
                logging.info("no detection return to client")
                break
        s.close()
def upload(image_name):
    print('begin to upload')
    upload_url='http://127.0.0.1:1111'
    f1 = open(image_name, 'rb')
    files = {
        'filename': image_name, 'file': f1}
    # print(files)
    head = {
        # "Content-Type": "multipart/form-data; boundary=alamofire.boundary.3c7024a080e6a27f",  #注意，此处不要写Content-Type
        "apiVersion": "v1.0.0",
        "appVersion": "v1.0.0",
        "OS": "iOS",
        "OSVersion": "11.4.1",
        "language": "zh",
        "did": "NTIzOTIxNDYwMzMyM2NjZjk1OGM5NjBmYzNlNzg2OTYtZTkxNzg1MzYzNjA4NGM0Mjg4Njg3MmFhNzExMDE1YTgwMDAyLXIwWUtuK0MrS1Y2eDBteWs3WnhDYmQ2ZnovTT0=",
        "reqSeq": "eb144eed4639d36bb6a7b9aa2a563421",
        "timestamp": "1545789471",
        "userToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJiaXpUeXBlIjoiTE9BTiIsInVzZXJSb2xlIjoyLCJleHAiOjE1NTQ2MTYwMjUsInVzZXJJZCI6MzAxMzkyNDUxNTc3Mzk3MjQ4LCJjaGVja0NvZGUiOiJiZTk1MDEwZjczN2Q0YTU2ODkxNTYyMDBlNDhhZDEyZCJ9.97Km63wUC6IaoSYE1Db8fAxYoW5N-ZQkbiw4kETN2cQ"
    }
    try:
        response = requests.post(
            url=upload_url, headers=head, files=files)
        print('finish uploading')
    except:
        print('bad thing')
        return {'data':'not linked to the Cloud'}

# r = redis.StrictRedis(host="39.107.107.87", port=16379,password="yfzne@2008.com", db=1)
if __name__ == "__main__":
    r = redis.StrictRedis(host="127.0.0.1", port=6379,password="", db=1)
    p = r.pubsub()   #创建发布对象
    p.subscribe("first channel")  #发布订阅消息
    logging.basicConfig(level=logging.DEBUG, format='levelname:%(levelname)s filename: %(filename)s ' 'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]', filename='./redisConsumer.log', filemode="a")
    while True:
      try:
        picnames = p.listen()
        for picname in picnames:
            print(picname)
            if picname["type"] == "message":
                #print(picname['data'])
                #filename=str(picname['data'],encoding="utf-8")
                filename=str(picname['data'], encoding = "utf8")
                print(filename)
                logging.info(filename)
                #upload(filename)
                #sock_client_image(filename,'39.107.107.87',6666)
                sock_client_image(filename,'192.168.3.222',6666)
                #socket_client(filename,'39.107.107.87',6666)
      except:
        logging.error("There is a error in this file", exc_info=1)
        time.sleep(10)
        continue 

