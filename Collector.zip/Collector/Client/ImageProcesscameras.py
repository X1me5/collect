# @Time    : 2020/12/28 3:47 下午
# @Author  : Ximes
# @FileName: ImageProcess.py
# -- coding: utf-8 --
import sys
import threading
sys.path.append(r"../MvImport")
from MvCameraControl_class import *
import sizeadjust
from ctypes import *
import time
import shutil
import logging
import uploadInformation

class ImageProcess():
    def __init__(self, realpart=0, imagpart=0):
        self.r = realpart
        self.i = imagpart
        print(self.r)
        print(self.i)

    def __del__(self):
        pass

    # Get the list of devices
    def deviceList(self):
        deviceList = MV_CC_DEVICE_INFO_LIST()
        return deviceList

    # Get the type of devices
    def tlayerType(self):
        tlayerType = MV_GIGE_DEVICE | MV_USB_DEVICE
        return tlayerType

    # Enumerate devices
    def deviceEnum(self, tlayerType, deviceList):
        ret = MvCamera.MV_CC_EnumDevices(tlayerType, deviceList)
        if ret != 0:
            print("enum devices fail! ret[0x%x]" % ret)
            sys.exit()

        if deviceList.nDeviceNum == 0:
            print("find no device!")
            sys.exit()

        print("find %d devices!" % deviceList.nDeviceNum)
        return deviceList.nDeviceNum

    # Create the handle of camera
    def CreateHandle(cam,number):
        stDeviceList = cast(deviceList.pDeviceInfo[number], POINTER(MV_CC_DEVICE_INFO)).contents
        ret = cam.MV_CC_CreateHandle(stDeviceList)
        if ret!=0:
            print("create handle fail! ret[0x%x]" % ret)
            sys.exit()
        return stDeviceList

    # Open camera
    def OpenDevice(cam):
        ret = cam.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
        if ret != 0:
            print("open device fail! ret[0x%x]" % ret)
            # sys.exit()
    #Detect network optimal package size(It only works for the GigE camera)
    def SET_PacketSize(cam,stDeviceList):
        if stDeviceList.nTLayerType == MV_GIGE_DEVICE:
            nPacketSize1 = cam.MV_CC_GetOptimalPacketSize()
            if int(nPacketSize1) > 0:
                ret = cam.MV_CC_SetIntValue("GevSCPSPacketSize", nPacketSize1)
                if ret != 0:
                    print("Warning: Set Packet Size fail! ret[0x%x]" % ret)
            else:
                print("Warning: Get Packet Size fail! ret[0x%x]" % nPacketSize1)

    # Set the trigger mode
    def SET_TRIGGER_MODE(cam):
        ret = cam.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
        if ret != 0:
            print("set trigger mode fail! ret[0x%x]" % ret)
            # sys.exit()

    # Get payload size
    def getParameter(cam):
        stParam = MVCC_INTVALUE()
        memset(byref(stParam), 0, sizeof(MVCC_INTVALUE))

        ret = cam.MV_CC_GetIntValue("PayloadSize", stParam)
        if ret != 0:
            print("get payload size fail! ret[0x%x]" % ret)
            sys.exit()
        nPayloadSize = stParam.nCurValue
        return nPayloadSize

    # Begin to grab image
    def StartGrabbing(cams,nPayloadSizes):
        rets = []
        data_bufs = []
        for number in range(len(cams)):
            ret=cams[number].MV_CC_StartGrabbing()
            if ret != 0:
                print("start grabbing fail! ret[0x%x]" % ret)
                #sys.exit()
            rets.append(ret)
            data_bufs.append((c_ubyte * nPayloadSizes[number])())
        for number in range(len(cams)):
            while True:
                try:
                    hThreadHandle = threading.Thread(
                        target = ImageProcess.work_thread, args = (
                        number,cams[number], byref(data_bufs[number]), nPayloadSizes[number]))
                    hThreadHandle.start()
                    break
                except:
                    print("error: unable to start thread")
                    continue
        print("press a key to stop grabbing.")

        g_bExit = True
        hThreadHandle.join()

    # Stop grabbing image
    def StopGrabbing(cam):
        ret = cam.MV_CC_StopGrabbing()
        if ret != 0:
            print("stop grabbing fail! ret[0x%x]" % ret)
            #del data_buf
            # sys.exit()

    # Close devices
    def CloseDevice(cam):
        ret = cam.MV_CC_CloseDevice()
        if ret != 0:
            print("close deivce fail! ret[0x%x]" % ret)
            #del data_bufs[number]
            # sys.exit()

    # ch:销毁句柄 | Destroy handle
    def DestroyHandle(cam):
        ret = cam.MV_CC_DestroyHandle()
        if ret != 0:
            print("destroy handle fail! ret[0x%x]" % ret)
            del data_buf
            # sys.exit()

    def work_thread(number,cam=0,pData=0,nDataSize=0):
        interval = 2
        stFrameInfo = MV_FRAME_OUT_INFO_EX()
        memset(byref(stFrameInfo), 0, sizeof(stFrameInfo))
        # make the log
        logging.basicConfig(level=logging.DEBUG,
                            format='levelname:%(levelname)s filename: %(filename)s '
                                   'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
                                   ' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
                            filename='./Imageprocess.log', filemode="a")
        while True:
            #time_remaining = interval - time.time() % interval
            #if (time_remaining >= 0):
                #time.sleep(time_remaining)
            #else:
                #time.sleep((-time_remaining) % 2)
            flag = input('whether to grab?(y/n)')
            if flag == 'y':
                data_buf = (c_ubyte * nPayloadSizes[number])()
                ret = cam.MV_CC_GetOneFrameTimeout(
                    byref(data_buf), nDataSize, stFrameInfo, 1000)
                if ret == 0:
                    print("get one frame: Width[%d], Height[%d], PixelType[0x%x], nFrameNum[%d]" % (
                        stFrameInfo.nWidth, stFrameInfo.nHeight, stFrameInfo.enPixelType, stFrameInfo.nFrameNum))
                    stConvertParam = MV_SAVE_IMAGE_PARAM_EX()
                    stConvertParam.nWidth = stFrameInfo.nWidth
                    stConvertParam.nHeight = stFrameInfo.nHeight
                    stConvertParam.pData = data_buf
                    stConvertParam.nDataLen = stFrameInfo.nFrameLen
                    stConvertParam.enPixelType = stFrameInfo.enPixelType

                    now = time.strftime("%Y-%m-%d-%H-%M-%S",
                                        time.localtime(time.time()))
                    file_name = str(number)+'-'+now + ".jpg"
                    file_path = 'data/' + file_name
                    stConvertParam.enImageType = MV_Image_Bmp
                    bmpsize = stFrameInfo.nWidth * stFrameInfo.nHeight * 3 + 54
                    stConvertParam.nBufferSize = bmpsize
                    bmp_buf = (c_ubyte * bmpsize)()
                    stConvertParam.pImageBuffer = bmp_buf

                    ret = cam.MV_CC_SaveImageEx2(stConvertParam)
                    while ret != 0:
                         print('regrab')
                         ret = cam.MV_CC_GetOneFrameTimeout(byref(data_buf), nDataSize, stFrameInfo, 1000)
                    file_open = open(file_path.encode('ascii'), 'wb+')
                    try:
                        img_buff = (c_ubyte * stConvertParam.nDataLen)()
                        memmove(byref(img_buff), stConvertParam.pImageBuffer,
                                stConvertParam.nDataLen)
                        file_open.write(img_buff)
                    except Exception as e:
                        raise Exception("save file executed failed1::%s" % e)
                    finally:
                        file_open.close()

                    # change size
                    sizeadjust.changesize(file_path)

                    # copy file for uploading to aliyun,the original file is the back-up
                    shutil.copy(file_path, 'testdata')
                    try:
                        if file_name != " ":
                            logging.info(file_name + " has been saved.")
                    except:
                        logging.error("There is a error in this file", exc_info=1)
                else:
                    print("camera"+str(number)+" no data[0x%x]" % ret)
                    logging.info("camera"+str(number)+" no data[0x%x]" % ret)
                if g_bExit == True:
                    break




if __name__ == "__main__":
    # logging
    logging.basicConfig(level=logging.INFO,
                        format='levelname:%(levelname)s filename: %(filename)s '
                               'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
                               ' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
                        filename='./ImageProcess.log', filemode="a")
    # device
    imageProcess = ImageProcess(realpart=1)
    deviceList = imageProcess.deviceList()
    tlayerType = imageProcess.tlayerType()
    deviceEnum = imageProcess.deviceEnum(tlayerType, deviceList)
    g_bExit = False
    deviceInfos = []
    #Step1:Get information of cameras
    for i in range(0, deviceList.nDeviceNum):
        deviceInfo = dict()
        mvcc_dev_info = cast(deviceList.pDeviceInfo[i], POINTER(
            MV_CC_DEVICE_INFO)).contents
        # 如果是Gige设备
        if mvcc_dev_info.nTLayerType == MV_GIGE_DEVICE:
            # 设备ID
            print("\ngige device: [%d]" % i)
            strDeviceID = i
            print("device id: %s" % strDeviceID)
            deviceInfo['deviceID'] = strDeviceID

            # 型号
            strModeName = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName:
                strModeName = strModeName + chr(per)
            print("device model name: %s" % strModeName)
            deviceInfo['modeName'] = strModeName.replace('\x00','')

            # 厂商名称
            strManufacturerName = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chManufacturerName:
                strManufacturerName = strManufacturerName + chr(per)
            print("device manufacturer name: %s" % strManufacturerName)
            deviceInfo['manufacturerName'] = strManufacturerName.replace('\x00','')

            # 设备版本
            strDeviceVersion = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chDeviceVersion:
                strDeviceVersion = strDeviceVersion + chr(per)
            print("device version name: %s" % strDeviceVersion)
            deviceInfo['deviceVersion'] = strDeviceVersion.replace('\x00','')

            # 厂商特别信息
            strManufacturerSpecificInfo = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chManufacturerSpecificInfo:
                strManufacturerSpecificInfo = strManufacturerSpecificInfo + \
                    chr(per)
            print("device manufacturer specific info: %s" %
                  strManufacturerSpecificInfo)
            deviceInfo['manufacturerSpecificInfo'] = strManufacturerSpecificInfo.replace('\x00','')

            # 序列号
            strSerialNumber = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chSerialNumber:
                strSerialNumber = strSerialNumber + chr(per)
            print("device serial number: %s" % strSerialNumber)
            deviceInfo['serialNumber'] = strSerialNumber.replace('\x00','')

            # 用户定义名称
            strUserDefinedName = ""
            for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chUserDefinedName:
                strUserDefinedName = strUserDefinedName + chr(per)
            print("device user defined name: %s" % strUserDefinedName)
            deviceInfo['userDefinedName'] = strUserDefinedName.replace('\x00','')

            # IP地址
            nip1 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24)
            nip2 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16)
            nip3 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8)
            nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
            print("current ip: %d.%d.%d.%d" % (nip1, nip2, nip3, nip4))
            strCurrentIp = '.'.join(
                [str(nip1), str(nip2), str(nip3), str(nip4)])
            deviceInfo['currentIp'] = strCurrentIp

            # 子网掩码
            nnetmask1 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentSubNetMask & 0xff000000) >> 24)
            nnetmask2 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentSubNetMask & 0x00ff0000) >> 16)
            nnetmask3 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentSubNetMask & 0x0000ff00) >> 8)
            nnetmask4 = (
                mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentSubNetMask & 0x000000ff)
            print("current netmask: %d.%d.%d.%d" %
                  (nnetmask1, nnetmask2, nnetmask3, nnetmask4))
            strCurrentSubNetMask = '.'.join(
                [str(nnetmask1), str(nnetmask2), str(nnetmask3), str(nnetmask4)])
            deviceInfo['currentSubNetMask'] = strCurrentSubNetMask

            # 默认网关
            ngateway1 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nDefultGateWay & 0xff000000) >> 24)
            ngateway2 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nDefultGateWay & 0x00ff0000) >> 16)
            ngateway3 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nDefultGateWay & 0x0000ff00) >> 8)
            ngateway4 = (
                mvcc_dev_info.SpecialInfo.stGigEInfo.nDefultGateWay & 0x000000ff)
            print("current gateway: %d.%d.%d.%d" %
                  (ngateway1, ngateway2, ngateway3, ngateway4))
            strcurrentGateWay = '.'.join(
                [str(ngateway1), str(ngateway2), str(ngateway3), str(ngateway4)])
            deviceInfo['currentGateWay'] = strcurrentGateWay

            # 网络其他
            nnetexport1 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nNetExport & 0xff000000) >> 24)
            nnetexport2 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nNetExport & 0x00ff0000) >> 16)
            nnetexport3 = (
                (mvcc_dev_info.SpecialInfo.stGigEInfo.nNetExport & 0x0000ff00) >> 8)
            nnetexport4 = (
                mvcc_dev_info.SpecialInfo.stGigEInfo.nNetExport & 0x000000ff)
            print("NetExport: %d.%d.%d.%d" %
                  (nnetexport1, nnetexport2, nnetexport3, nnetexport4))
            strNetExport = '.'.join(
                [str(nnetexport1), str(nnetexport2), str(nnetexport3), str(nnetexport4)])
            deviceInfo['netExport'] = strNetExport

            # Mac地址
            nMacAddrHigh1 = (
                (mvcc_dev_info.nMacAddrHigh & 0xff000000) >> 24)
            nMacAddrHigh2 = (
                (mvcc_dev_info.nMacAddrHigh & 0x00ff0000) >> 16)
            nMacAddrHigh3 = (
                (mvcc_dev_info.nMacAddrHigh & 0x0000ff00) >> 8)
            nMacAddrHigh4 = (mvcc_dev_info.nMacAddrHigh & 0x000000ff)
            print("mac address high: %02X:%02X:%02X:%02X" % (
                nMacAddrHigh1, nMacAddrHigh2, nMacAddrHigh3, nMacAddrHigh4))

            nMacAddrLow1 = ((mvcc_dev_info.nMacAddrLow & 0xff000000) >> 24)
            nMacAddrLow2 = ((mvcc_dev_info.nMacAddrLow & 0x00ff0000) >> 16)
            nMacAddrLow3 = ((mvcc_dev_info.nMacAddrLow & 0x0000ff00) >> 8)
            nMacAddrLow4 = (mvcc_dev_info.nMacAddrLow & 0x000000ff)
            print("mac address low: %02X:%02X:%02X:%02X" %
                  (nMacAddrLow1, nMacAddrLow2, nMacAddrLow3, nMacAddrLow4))
            print("mac address full: %02X:%02X:%02X:%02X:%02X:%02X" % (
                nMacAddrHigh3, nMacAddrHigh4, nMacAddrLow1, nMacAddrLow2, nMacAddrLow3, nMacAddrLow4))
            strMacAddr = ':'.join(
                [str(nMacAddrHigh3), str(nMacAddrHigh4), str(nMacAddrLow1), str(nMacAddrLow2), str(nMacAddrLow3), str(nMacAddrLow4)])
            deviceInfo['macAddr'] = strMacAddr

            deviceInfos.append(deviceInfo)
            
            #uploadInformation.upload(deviceInfo)
	    
        # 如果是USB设备
        elif mvcc_dev_info.nTLayerType == MV_USB_DEVICE:
            print("\nu3v device: [%d]" % i)
            strModeName = ""
            for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chModelName:
                if per == 0:
                    break
                strModeName = strModeName + chr(per)
            print("device model name: %s" % strModeName)

            strSerialNumber = ""
            for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chSerialNumber:
                if per == 0:
                    break
                strSerialNumber = strSerialNumber + chr(per)
            print("user serial number: %s" % strSerialNumber)
    nConnectionNums = []
    for number in range(deviceList.nDeviceNum):
        nConnectionNums.append(number)     #get all the number of camera to connect
    #Step2 : Go through the deviceList to create the camera object
    cams = []
    for number in range(deviceList.nDeviceNum) :
        cams.append(MvCamera())
    stDeviceLists = []
    #Step3 : Go through the cams to create the handle
    for number in range(len(cams)):
        stDeviceLists.append(ImageProcess.CreateHandle(cams[number],number))
    #Step4 : Open all of the camera
    for number in range(len(cams)):
        ImageProcess.OpenDevice(cams[number])
    #Step5 : Detect the network optimal package size(It only works for the GigE camera)
    for number in range(len(cams)):
        ImageProcess.SET_PacketSize(cams[number], stDeviceLists[number])
    #Step6 : Set the trigger mode
    for number in range(len(cams)):
        ImageProcess.SET_TRIGGER_MODE(cams[number])
    #Step7 : Get payload size
    nPayloadSizes=[]
    for number in range(len(cams)):
        nPayloadSizes.append(ImageProcess.getParameter(cams[number]))
    #Step8 : Begin to Grab
    ImageProcess.StartGrabbing(cams,nPayloadSizes)
    #Step9 : Stop Grabbing
    #ImageProcess.StopGrabbing(cam)
    #Step10: Close the device
    #ImageProcess.CloseDevice(cam)
    #Step11: Destroy the handle
    #ImageProcess.DestroyHandle(cam)
