# -*- coding: utf-8 -*
import requests
from watchdog.observers import Observer
from watchdog.events import *
import time
import redis
class FileEventHandler(FileSystemEventHandler):
    def __init__(self):
        FileSystemEventHandler.__init__(self)

    # def on_moved(self, event):
    #     if event.is_directory:
    #         print("directory moved from {0} to {1}".format(event.src_path,event.dest_path))
    #     else:
    #         print("file moved from {0} to {1}".format(event.src_path,event.dest_path))

    def on_created(self, event):
        # if event.is_directory:
        #     print("directory created:{0}".format(event.src_path))
        # else:
        print("pic saved:{0}".format(event.src_path))
        try:
            if event.src_path!=" ":
                logging.info(event.src_path + " has been saved.")
                r.publish("first channel",event.src_path)
        except:
            logging.error("There is a error in this file", exc_info=1)

    # def on_deleted(self, event):
    #     if event.is_directory:
    #         print("directory deleted:{0}".format(event.src_path))
    #     else:
    #         print("file deleted:{0}".format(event.src_path))

    # def on_modified(self, event):
    #     if event.is_directory:
    #         print("directory modified:{0}".format(event.src_path))
    #     else:
    #         print("file modified:{0}".format(event.src_path))
def upload(image_name):
    upload_url='http://39.107.107.87:6666'
    f1 = open(image_name, 'rb')
    files = {
        'filename': image_name, 'file': f1}
    # print(files)
    head = {
        # "Content-Type": "multipart/form-data; boundary=alamofire.boundary.3c7024a080e6a27f",  #注意，此处不要写Content-Type
        "apiVersion": "v1.0.0",
        "appVersion": "v1.0.0",
        "OS": "iOS",
        "OSVersion": "11.4.1",
        "language": "zh",
        "did": "NTIzOTIxNDYwMzMyM2NjZjk1OGM5NjBmYzNlNzg2OTYtZTkxNzg1MzYzNjA4NGM0Mjg4Njg3MmFhNzExMDE1YTgwMDAyLXIwWUtuK0MrS1Y2eDBteWs3WnhDYmQ2ZnovTT0=",
        "reqSeq": "eb144eed4639d36bb6a7b9aa2a563421",
        "timestamp": "1545789471",
        "userToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJiaXpUeXBlIjoiTE9BTiIsInVzZXJSb2xlIjoyLCJleHAiOjE1NTQ2MTYwMjUsInVzZXJJZCI6MzAxMzkyNDUxNTc3Mzk3MjQ4LCJjaGVja0NvZGUiOiJiZTk1MDEwZjczN2Q0YTU2ODkxNTYyMDBlNDhhZDEyZCJ9.97Km63wUC6IaoSYE1Db8fAxYoW5N-ZQkbiw4kETN2cQ"
    }
    try:
        response = requests.post(
            url=upload_url, headers=head, files=files)
    except:
        return {'data':'not linked to the Cloud'}
if __name__ == '__main__':
    #logging
    logging.basicConfig(level=logging.INFO,
                        format='levelname:%(levelname)s filename: %(filename)s '
                               'outputNumber: [%(lineno)d] thread: %(threadName)s output msg: %(message)s'
                               ' - %(asctime)s', datefmt='[%d/%b/%Y %H:%M:%S]',
                        filename='./redisproducer.log', filemode="a")
    #redis
    r = redis.StrictRedis(host="127.0.0.1", port=6379,
                          password="", db=1)
    #watchdog
    observer = Observer()
    event_handler = FileEventHandler()
    # Windows
    #observer.schedule(event_handler, "/Users/ximes/WeDrive/江苏亿方众能电子科技有限公司/Aibrush/test", True)
    # Linux、服务器
    observer.schedule(event_handler,"./testdata",True)
    observer.start()
    try:#有待研究看门狗线程自杀
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
