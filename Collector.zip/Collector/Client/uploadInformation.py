# -*- coding: utf-8 -*
import requests
import json
def upload(data):
	post_headers = {'Content-Type':'application/json',"Accept": "*/*"}
	print(str(data))
	r = requests.post('http://aibrush.yfzne.com/system/equipmentstatus/save', data = json.dumps(data),headers=post_headers)
	print('finish uploading')
	# r = requests.post('http://127.0.0.1/system/aibrush/deploy', data = 			    json.dumps(data),headers=post_headers)



